//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by KineChain.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_SETROTATE                   130
#define IDD_SETRESTRICT                 130
#define IDC_XAXIS                       1000
#define IDC_DAMP0                       1000
#define IDC_YAXIS                       1001
#define IDC_MINROT0                     1001
#define IDC_ZAXIS                       1002
#define IDC_MAXROT0                     1002
#define IDC_DAMP1                       1003
#define IDC_MINROT1                     1004
#define IDC_MAXROT1                     1005
#define IDC_DAMP2                       1006
#define IDC_MINROT2                     1007
#define IDC_MAXROT2                     1008
#define IDC_DAMP3                       1009
#define IDC_MINROT3                     1010
#define IDC_MAXROT3                     1011
#define IDC_DAMP4                       1012
#define IDC_MINROT4                     1013
#define IDC_MAXROT4                     1014
#define ID_VIEW_GEOMETRY                32771
#define ID_VIEW_USEQUATERNIONS          32772
#define ID_HELP_WHICHOPENGL             32774
#define ID_OPTIONS_DAMPING              32775
#define ID_OPTIONS_DOFRESTRICTIONS      32776
#define ID_OPTIONS_DOF                  32777
#define ID_OPTIONS_SETRESTRICTIONS      32778
#define ID_INDICATOR_ROT2               59142
#define ID_INDICATOR_QUAT               59143
#define ID_INDICATOR_ROT                59144
#define ID_INDICATOR_LOWROT             59144
#define ID_INDICATOR_STATUS             59145
#define ID_INDICATOR_UPROT              59145
#define ID_INDICATOR_BASEROT            59146

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
