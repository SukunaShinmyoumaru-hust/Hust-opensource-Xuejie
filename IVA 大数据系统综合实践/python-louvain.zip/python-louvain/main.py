import time
import networkx as nx
from community import community_louvain
# import matplotlib.cm as cm
# import matplotlib.pyplot as plt

# 记录程序开始时间
start_time = time.time()

# 加载图数据
# 假设文件 Cit-HepPh.txt 每一行表示一条边，例如：1 2
G = nx.read_edgelist('Cit-HepPh.txt', nodetype=int)
# G = nx.read_edgelist('soc-LiveJournal1.txt', nodetype=int, comments='#')

# compute the best partition
partition = community_louvain.best_partition(G)

# 输出每个社区包含的节点
print('Cit-HepPh.txt')
# print('soc-LiveJournal1.txt')
print("按社区分组的节点：")
communities = {}
for node, community in partition.items():
    if community not in communities:
        communities[community] = []
    communities[community].append(node)

# 打印每个社区及其包含的节点
for community, nodes in communities.items():
    print(f"社区 {community}: {nodes}")

# 输出发现的社区总数
print(f"\n发现的社区总数: {len(communities)}")

# 记录程序结束时间并计算总时长
end_time = time.time()
execution_time = end_time - start_time

# 输出程序执行时间
# print(f"程序执行时间: {execution_time:.4f} 秒")
print(f"程序执行时间: {execution_time:.4f} 秒")

# # draw the graph
# pos = nx.spring_layout(G)
# # color the nodes according to their partition
# cmap = cm.get_cmap('viridis', max(partition.values()) + 1)
# nx.draw_networkx_nodes(G, pos, partition.keys(), node_size=40,
#                        cmap=cmap, node_color=list(partition.values()))
# nx.draw_networkx_edges(G, pos, alpha=0.5)
# plt.show()
